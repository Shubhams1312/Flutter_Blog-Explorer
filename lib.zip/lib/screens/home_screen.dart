import 'package:f_project/screens/detail_blog_screen.dart';
import 'package:f_project/service/blog_req.dart';
import 'package:flutter/material.dart';

import '../model/blog_response_model.dart';

class HomeScreen extends StatefulWidget {
  HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  BlogRequest _blogRequest = BlogRequest();
  BlogResponseModel? blogs ;

  // @override
  // void initState() {
  //   // TODO: implement initState
  //   super.initState();
  //   _blogRequest.fetchBlogs();

  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Menu"),
        actions: const[
          Padding(
            padding:  EdgeInsets.only(right: 10),
            child: CircleAvatar(child: Icon(Icons.menu,)),
            ),
        ]
        ),

        body: Column(children: [
          Flexible(
            child: 
            FutureBuilder( //
              future: _blogRequest.fetchBlogs(),
              builder: ((context, snapshot) {
                if(snapshot.hasData){
                  print("Snapshot: ${snapshot.data}");
                  return ListView.builder(
                    itemCount: snapshot.data?.blogs.length,
                    itemBuilder: (context, index) {
                      return  InkWell(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: ((context) => DetailedBlockedScreen(
                            id: snapshot.data?.blogs[index].id,
                            image: snapshot.data?.blogs[index].imageUrl,
                            title: snapshot.data?.blogs[index].title) ))); 
                        },
                        onDoubleTap: () {

                          setState(() {
                            if(snapshot.data?.blogs[index].fav == true){
                            snapshot.data?.blogs[index].fav = false;
                          }
                          else{
                            snapshot.data?.blogs[index].fav = true;
                          }
                          });

                        },
                        child: Column(
                          children: [
                            Stack(
                              children:[ Padding(
                                              padding: const EdgeInsets.only(left: 14 , right: 14 , top: 7 , bottom: 7), 
                                              child:  Container(
                                                height: MediaQuery.of(context).size.height / 2,
                                                padding: const EdgeInsets.all(2),
                                                 decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.5),
                              borderRadius: BorderRadius.circular(15)
                                                 ),
                                                 child: Column(children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(15),
                                child: Image.network(snapshot.data!.blogs[index].imageUrl ,
                                height:MediaQuery.of(context).size.height*0.4 ,
                                fit: BoxFit.fill,
                                width: MediaQuery.of(context).size.width,
                                ),
                                
                              ),
                              const SizedBox(height: 20,),
                              Text(snapshot.data!.blogs[index].title, style: const TextStyle(fontSize: 15,fontWeight: FontWeight.bold),textAlign: TextAlign.center,),
                                                 ],
                                                 ),
                                              ),
                                              ),
                                              Positioned(
                                                top: 20,
                                                left: MediaQuery.of(context).size.width / 1.2,
                                                child: Icon(
                                                  Icons.favorite , 
                                                  size: 30,
                                                  color: snapshot.data!.blogs[index].fav == true ? Colors.red : Colors.white,
                                                  )),
                              ]
                            ),
                                            const Divider(color: Colors.black54,),
                          ],
                        ),
                      );
                    });
                }
                return const Center(child: CircularProgressIndicator());
              } )),
              ),
        ]),
    );
  }
}